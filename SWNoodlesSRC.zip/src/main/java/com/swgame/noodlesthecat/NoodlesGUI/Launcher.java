package com.swgame.noodlesthecat.NoodlesGUI;

public class Launcher {
    public static void main(String[] args) {
        NoodlesGUI.main(args);
    }
}
