/*Shelby Williams
Advanced Java
12-18-21
Noodles the Cat Point-and-Click Adventure Game
Coordinates class - Used to set X/Y axis for on-screen clickable items
API for all imported libraries used as references.
*/

package com.swgame.noodlesthecat.NoodlesGUI;

public class Coordinates {
    public Coordinates(int x, int y) {
        this.x = x;
        this.y = y;
    }

    public int x;
    public int y;
}
